define({
  "_themeLabel": "Dėžučių tema",
  "_layout_default": "Numatytasis maketas",
  "_layout_top": "Viršutinis maketas"
});