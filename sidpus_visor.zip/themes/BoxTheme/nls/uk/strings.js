define({
  "_themeLabel": "Тема Box",
  "_layout_default": "Компонування за замовчуванням",
  "_layout_top": "Компонування зверху"
});