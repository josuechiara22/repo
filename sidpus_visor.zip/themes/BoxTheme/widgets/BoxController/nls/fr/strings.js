define({
  "_widgetLabel": "Contrôleur de boîte"
});