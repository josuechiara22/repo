define({
  "_widgetLabel": "Loga kontrolleris"
});