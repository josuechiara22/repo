define({
  "_widgetLabel": "בקר תיבה"
});