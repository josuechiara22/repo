define({
  "_themeLabel": "Motiv rámečku",
  "_layout_default": "Výchozí rozvržení",
  "_layout_top": "Horní rozvržení"
});